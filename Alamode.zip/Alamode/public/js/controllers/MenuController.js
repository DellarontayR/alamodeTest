'use strict';
// angular.module('alamode.controllers',['authServices','userServices','cartServices'])
alamode.controller('TestController',function($scope, Product,Cart, User) {

	var app = this;

});